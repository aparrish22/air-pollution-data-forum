from django.apps import AppConfig


class PlotthreeConfig(AppConfig):
    name = 'plotthree'
