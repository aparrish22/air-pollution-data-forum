from django.apps import AppConfig


class PlotoneConfig(AppConfig):
    name = 'plotone'
