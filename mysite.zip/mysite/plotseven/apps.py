from django.apps import AppConfig


class PlotsevenConfig(AppConfig):
    name = 'plotseven'
