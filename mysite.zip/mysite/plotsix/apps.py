from django.apps import AppConfig


class PlotsixConfig(AppConfig):
    name = 'plotsix'
