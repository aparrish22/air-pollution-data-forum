1. >> python -m pip install pipenv
2. Make your project's parent directory:
   on the console
   >> mkdir parentdirectory_name
   >> cd parentdirectory_name
3. Create pipenv virtual environment:
   pipenv install
4. Activate your environment:
   >> cd \path\to\mysite\
   >> pipenv shell
5. Install requirements.txt:
   >> pip install -r requirements.txt
6. >> py manage.py runserver
