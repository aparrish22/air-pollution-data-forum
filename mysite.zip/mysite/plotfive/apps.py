from django.apps import AppConfig


class PlotfiveConfig(AppConfig):
    name = 'plotfive'
