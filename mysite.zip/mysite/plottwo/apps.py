from django.apps import AppConfig


class PlottwoConfig(AppConfig):
    name = 'plottwo'
