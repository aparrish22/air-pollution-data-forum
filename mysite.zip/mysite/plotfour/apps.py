from django.apps import AppConfig


class PlotfourConfig(AppConfig):
    name = 'plotfour'
