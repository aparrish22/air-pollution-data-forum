from django.apps import AppConfig


class PollutionConfig(AppConfig):
    name = 'pollution'
