from django.apps import AppConfig


class UploadfileConfig(AppConfig):
    name = 'uploadfile'
